روشتة Rx - مشروع Android

هذا مشروع Android Studio جاهز لتحويل لعبة HTML المرفقة إلى تطبيق Android يعمل دون إنترنت.
اللعبة موجودة داخل app/src/main/assets/index.html وتُفتح محلياً داخل WebView.

لإنشاء APK:
1) افتح Android Studio واختر Open ثم اختر مجلد RxGame.
2) انتظر اكتمال Gradle Sync (قد يحتاج اتصال إنترنت أول مرة لتنزيل أدوات البناء).
3) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
4) ستجد الملف عادةً في: app/build/outputs/apk/debug/app-debug.apk

إعدادات التطبيق:
- الاسم: روشتة Rx
- package: com.rxgame.app
- minimum Android: 6.0 (API 23)
- اللعبة مضمّنة بالكامل وتعمل محلياً دون اتصال بالإنترنت.
- حفظ التقدم يعتمد على تخزين المتصفح المحلي داخل WebView.

ملاحظة: هذا الملف مشروع مصدر جاهز للبناء، وليس APK مبنياً. بيئة التنفيذ الحالية لا تحتوي Android SDK أو Gradle لبناء APK فعلي هنا.
